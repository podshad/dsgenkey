# OrionNitroGenerator | In development
Discord nitro generator from your pocket
---
This application is designed for android devices.
---
# How to use it?
1. Download the apk file 
2. Open the app 
3. In the appropriate field, insert your discord token (optional) 
4. Start generation 
5. You can minimize the application (BUT NOT CLOSE IT) and continue using your phone 
6. After a couple of hours, check the results of generation 
7. Stop the application

---
You can put the phone on overnight and check the generation results in the morning.
